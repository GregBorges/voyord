#Suryoday Automation

Suryoday is an NGO(Non-Profit Organization) which is run by PP Guruji. It works for many social causes. Development Center of IIPS DAVV is contributing towards the automation of this trust.

