<div dojoType="dijit.layout.TabContainer" style="width: 100%; height: 100%;"> 
    <div dojoType="dijit.layout.ContentPane" title="Tab1"> This is the content in tab 1. </div> 
    <div dojoType="dijit.layout.ContentPane" title="Tab 2"> This is the content in tab 2. </div> 
</div>